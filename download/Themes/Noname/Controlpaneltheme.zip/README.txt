1. Unzip and upload "app.css" and "app.css.map" in /var/www/dashboard/public/css
2. If it does not update correctly, please use this: CTRL+F5
3. Enjoy! ;)

---------------------------------------------------------------------------------
Discord: https://dsc.gg/u-hosting

Give me feedback, please!