1. Unzip and Upload to /var/www/dashboard/public/css
2. Enjoy. 
______________
CSS by 2IceCube#0110 and 2IceCube#8932
Website: https://2icecube.de
Discord: https://discord.2icecube.de
