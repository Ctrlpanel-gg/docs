---- Install Instructions ----

1. Copy the app.css and app.css.map file and paste it into /var/www/dashboard/public/css/

---- Warning ----

If the site does not update correctly, use CTRL + F5

---- End ----

Now, lastly, have fun with the Theme!

https://dsc.gg/u-hosting

I would really appreciate it if you would give me feedback, you can contact me via the Controlpanel Server or per DM's!
unrexIstIq#9898

---- TOS ----

You may not resell or redistribute this Theme or say something like: "Look, I made a theme by myself", all credits belong to me.